import React, { useEffect, useState } from "react";

function StudentProfileFunction() {
  const [student, setStudent] = useState(null);

  useEffect(() => {
    console.log("useEffect: Component mounted");

    // Mock API call
    const timer = setTimeout(() => {
      setStudent({
        name: "Chinni",
        course: "B.Tech",
        year: "3rd Year",
      });
    }, 1000);

    // Cleanup (unmount)
    return () => {
      console.log("useEffect cleanup: Component unmounted");
      clearTimeout(timer);
    };
  }, []);

  return (
    <div style={{ border: "2px solid green", padding: "15px", marginTop: "10px" }}>
      <h2>Student Profile (Functional)</h2>

      {student ? (
        <>
          <p>Name: {student.name}</p>
          <p>Course: {student.course}</p>
          <p>Year: {student.year}</p>
        </>
      ) : (
        <p>Loading...</p>
      )}
    </div>
  );
}

export default StudentProfileFunction;